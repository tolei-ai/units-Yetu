"use client"

import type React from "react"

import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import {
  AlertTriangle,
  Bell,
  Calendar,
  ChevronDown,
  Globe,
  Heart,
  Home,
  LineChart,
  LogOut,
  Menu,
  Moon,
  PieChart,
  Plus,
  Search,
  Settings,
  Sun,
  User,
  Users,
  X,
  Zap,
} from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"

interface SidebarItemProps {
  icon: React.ElementType
  title: string
  href?: string
  isActive?: boolean
  isOpen?: boolean
  subItems?: { title: string; href: string }[]
  onClick?: () => void
  badge?: string
  badgeVariant?: "default" | "outline" | "secondary" | "destructive"
}

function SidebarItem({
  icon: Icon,
  title,
  href,
  isActive,
  isOpen,
  subItems,
  onClick,
  badge,
  badgeVariant = "outline",
}: SidebarItemProps) {
  const pathname = usePathname()
  const [open, setOpen] = useState(() => {
    // Open the dropdown if any sub-item is active
    if (subItems) {
      return subItems.some((item) => pathname.includes(item.href))
    }
    return false
  })

  const hasSubItems = subItems && subItems.length > 0

  return (
    <div className="mb-2">
      {hasSubItems ? (
        <Collapsible open={open} onOpenChange={setOpen}>
          <CollapsibleTrigger asChild>
            <button
              className={cn(
                "flex w-full items-center justify-between rounded-md px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-gradient-to-r from-indigo-600 to-blue-600 text-white dark:from-indigo-500 dark:to-blue-500"
                  : "text-foreground hover:bg-accent/50 dark:text-slate-200 dark:hover:bg-slate-800/50",
              )}
              onClick={onClick}
            >
              <div className="flex items-center">
                <Icon className="mr-2 h-4 w-4" />
                {title}
                {badge && (
                  <Badge variant={badgeVariant} className="ml-2 px-1 py-0 h-5">
                    {badge}
                  </Badge>
                )}
              </div>
              <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} />
            </button>
          </CollapsibleTrigger>
          <CollapsibleContent className="pl-7 pt-1 space-y-1">
            {subItems.map((item, index) => (
              <Link
                key={index}
                href={item.href}
                className={cn(
                  "flex items-center rounded-md px-3 py-2 text-sm transition-colors",
                  pathname === item.href
                    ? "bg-accent/80 font-medium text-accent-foreground dark:bg-slate-800 dark:text-white"
                    : "text-foreground/70 hover:bg-accent/50 hover:text-accent-foreground dark:text-slate-300 dark:hover:bg-slate-800/30",
                )}
              >
                {item.title}
              </Link>
            ))}
          </CollapsibleContent>
        </Collapsible>
      ) : (
        <Link
          href={href || "#"}
          className={cn(
            "flex w-full items-center justify-between rounded-md px-3 py-2 text-sm font-medium transition-colors",
            pathname === href
              ? "bg-gradient-to-r from-indigo-600 to-blue-600 text-white dark:from-indigo-500 dark:to-blue-500"
              : "text-foreground hover:bg-accent/50 dark:text-slate-200 dark:hover:bg-slate-800/50",
          )}
          onClick={onClick}
        >
          <div className="flex items-center">
            <Icon className="mr-2 h-4 w-4" />
            {title}
          </div>
          {badge && (
            <Badge variant={badgeVariant} className="px-1 py-0 h-5">
              {badge}
            </Badge>
          )}
        </Link>
      )}
    </div>
  )
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const { toast } = useToast()
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [notifications, setNotifications] = useState(3)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [user, setUser] = useState<any>(null)

  // Check if user is authenticated
  useEffect(() => {
    const checkAuth = () => {
      const userData = localStorage.getItem("tambuaflow_user")
      if (userData) {
        setUser(JSON.parse(userData))
      } else {
        // For demo purposes, create a demo user if none exists
        const demoUser = {
          id: "user_demo",
          name: "Demo User",
          email: "demo@tambuaflow.com",
          company: "Demo Company",
          avatar: "", // You can add a default avatar URL here
          isAuthenticated: true,
        }
        localStorage.setItem("tambuaflow_user", JSON.stringify(demoUser))
        setUser(demoUser)
      }
    }

    checkAuth()
  }, [])

  // Toggle dark/light mode
  const toggleTheme = () => {
    document.documentElement.classList.toggle("dark")
    setIsDarkMode(!isDarkMode)
    localStorage.setItem("tambuaflow_theme", !isDarkMode ? "dark" : "light")
  }

  // Check theme preference
  useEffect(() => {
    const savedTheme = localStorage.getItem("tambuaflow_theme")
    if (savedTheme === "dark" || (!savedTheme && window.matchMedia("(prefers-color-scheme: dark)").matches)) {
      document.documentElement.classList.add("dark")
      setIsDarkMode(true)
    }
  }, [])

  // Handle logout
  const handleLogout = () => {
    localStorage.removeItem("tambuaflow_user")
    toast({
      title: "Logged out successfully",
      description: "You have been logged out of your account.",
    })
    router.push("/signin")
  }

  // Competitive Analysis sub-items
  const competitiveAnalysisSubItems = [
    { title: "Market Positioning", href: "/dashboard/competitive-analysis/market-positioning" },
    { title: "Audience & Engagement Trends", href: "/dashboard/competitive-analysis/audience-engagement" },
    { title: "Competitor Profile Tracker", href: "/dashboard/competitive-analysis/competitor-profiles" },
    { title: "Performance Overview", href: "/dashboard/competitive-analysis/performance" },
    { title: "Content Strategy & Engagement", href: "/dashboard/competitive-analysis/content-strategy" },
    { title: "Keywords & SEO Trends", href: "/dashboard/competitive-analysis/seo-trends" },
    { title: "Ad Spend & Digital Strategy", href: "/dashboard/competitive-analysis/ad-spend" },
    { title: "Market Sentiment", href: "/dashboard/competitive-analysis/sentiment" },
    { title: "Custom Visualization Tools", href: "/dashboard/competitive-analysis/visualization" },
  ]

  // Social Impact sub-items
  const socialImpactSubItems = [
    { title: "Business Growth", href: "/dashboard/social-impact/business-growth" },
    { title: "Sustainability", href: "/dashboard/social-impact/sustainability" },
    { title: "Community Engagement", href: "/dashboard/social-impact/community" },
    { title: "Economic Influence", href: "/dashboard/social-impact/economic" },
    { title: "Education & Upskilling", href: "/dashboard/social-impact/education" },
    { title: "Public Well-Being", href: "/dashboard/social-impact/well-being" },
    { title: "Brand Perception", href: "/dashboard/social-impact/brand-perception" },
    { title: "Custom Visualizations", href: "/dashboard/social-impact/visualizations" },
  ]

  // Community Engagement sub-items
  const communityEngagementSubItems = [
    { title: "Engagement Overview", href: "/dashboard/community/overview" },
    { title: "Multi-Platform Monitoring", href: "/dashboard/community/monitoring" },
    { title: "Sentiment Analysis", href: "/dashboard/community/sentiment" },
    { title: "Feedback Analysis", href: "/dashboard/community/feedback" },
    { title: "Response Metrics", href: "/dashboard/community/response-metrics" },
    { title: "Influencer Tracking", href: "/dashboard/community/influencers" },
  ]

  // Predictive Analytics sub-items
  const predictiveAnalyticsSubItems = [
    { title: "Performance Forecast", href: "/dashboard/predictive/performance" },
    { title: "Optimal Posting Times", href: "/dashboard/predictive/posting-times" },
    { title: "Engagement Trends", href: "/dashboard/predictive/engagement-trends" },
    { title: "Content Benchmarking", href: "/dashboard/predictive/benchmarking" },
    { title: "Content Recommendations", href: "/dashboard/predictive/recommendations" },
    { title: "Emerging Topics", href: "/dashboard/predictive/emerging-topics" },
    { title: "Sentiment Prediction", href: "/dashboard/predictive/sentiment" },
  ]

  // Social Listening sub-items
  const socialListeningSubItems = [
    { title: "Brand Mentions", href: "/dashboard/social-listening/mentions" },
    { title: "Sentiment Analysis", href: "/dashboard/social-listening/sentiment" },
    { title: "Trending Topics", href: "/dashboard/social-listening/trending" },
    { title: "Crisis Detection", href: "/dashboard/social-listening/crisis" },
    { title: "Competitive Benchmarking", href: "/dashboard/social-listening/benchmarking" },
  ]

  // Lead Generation sub-items
  const leadGenerationSubItems = [
    { title: "Overview", href: "/dashboard/lead-generation/overview" },
    { title: "Lead Management", href: "/dashboard/lead-generation/management" },
    { title: "Properties", href: "/dashboard/lead-generation/properties" },
    { title: "Campaigns", href: "/dashboard/lead-generation/campaigns" },
  ]

  // Crisis Management sub-items
  const crisisManagementSubItems = [
    { title: "Risk Dashboard", href: "/dashboard/crisis-management/risk-dashboard" },
    { title: "Personalized Issues", href: "/dashboard/crisis-management/issues" },
    { title: "Brand Advocates", href: "/dashboard/crisis-management/advocates" },
    { title: "Response Planning", href: "/dashboard/crisis-management/response" },
  ]

  // Content Calendar sub-items
  const contentCalendarSubItems = [
    { title: "Calendar View", href: "/dashboard/content-calendar/calendar" },
    { title: "Content Planner", href: "/dashboard/content-calendar/planner" },
    { title: "Content Analytics", href: "/dashboard/content-calendar/analytics" },
  ]

  // Command Center sub-items
  const commandCenterSubItems = [
    { title: "Overview", href: "/dashboard/command-center/overview" },
    { title: "Real-time Alerts", href: "/dashboard/command-center/alerts" },
    { title: "Critical Metrics", href: "/dashboard/command-center/metrics" },
  ]

  return (
    <div className="flex min-h-screen flex-col bg-background dark:bg-slate-950">
      {/* Mobile Header */}
      <header className="sticky top-0 z-50 flex h-14 items-center gap-4 border-b bg-background px-4 sm:px-6 dark:bg-slate-950 dark:border-slate-800 lg:hidden">
        <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="lg:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 p-0">
            <div className="flex h-14 items-center border-b px-4 dark:border-slate-800">
              <Link href="/" className="flex items-center gap-2">
                <Globe className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold">TambuaFlow</span>
              </Link>
              <Button variant="ghost" size="icon" className="ml-auto" onClick={() => setIsSidebarOpen(false)}>
                <X className="h-5 w-5" />
                <span className="sr-only">Close</span>
              </Button>
            </div>
            <nav className="grid gap-1 p-4 overflow-y-auto max-h-[calc(100vh-3.5rem)]">
              <SidebarItem icon={Home} title="Home" href="/dashboard" isActive={pathname === "/dashboard"} />
              <SidebarItem
                icon={LineChart}
                title="Competitive Analysis"
                isActive={pathname.includes("/dashboard/competitive-analysis")}
                subItems={competitiveAnalysisSubItems}
              />
              <SidebarItem
                icon={Globe}
                title="Social Impact"
                isActive={pathname.includes("/dashboard/social-impact")}
                subItems={socialImpactSubItems}
              />
              <SidebarItem
                icon={Heart}
                title="Community Engagement"
                isActive={pathname.includes("/dashboard/community")}
                subItems={communityEngagementSubItems}
              />
              <SidebarItem
                icon={PieChart}
                title="Predictive Analytics"
                isActive={pathname.includes("/dashboard/predictive")}
                subItems={predictiveAnalyticsSubItems}
              />
              <SidebarItem
                icon={Search}
                title="Social Listening"
                isActive={pathname.includes("/dashboard/social-listening")}
                subItems={socialListeningSubItems}
                badge="New"
              />
              <SidebarItem
                icon={Users}
                title="Lead Generation"
                isActive={pathname.includes("/dashboard/lead-generation")}
                subItems={leadGenerationSubItems}
              />
              <SidebarItem
                icon={AlertTriangle}
                title="Crisis Management"
                isActive={pathname.includes("/dashboard/crisis-management")}
                subItems={crisisManagementSubItems}
                badge="Alert"
                badgeVariant="destructive"
              />
              <SidebarItem
                icon={Calendar}
                title="Content Calendar"
                isActive={pathname.includes("/dashboard/content-calendar")}
                subItems={contentCalendarSubItems}
              />
              <SidebarItem
                icon={Zap}
                title="Command Center"
                isActive={pathname.includes("/dashboard/command-center")}
                subItems={commandCenterSubItems}
              />
              <SidebarItem
                icon={Settings}
                title="Settings"
                href="/dashboard/settings"
                isActive={pathname === "/dashboard/settings"}
              />
              <SidebarItem icon={LogOut} title="Logout" onClick={handleLogout} />
            </nav>
          </SheetContent>
        </Sheet>
        <Link href="/" className="flex items-center gap-2">
          <Globe className="h-6 w-6 text-primary" />
          <span className="text-lg font-bold">TambuaFlow</span>
        </Link>
        <div className="ml-auto flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="relative">
            {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            <span className="sr-only">{isDarkMode ? "Light mode" : "Dark mode"}</span>
            {isDarkMode && <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-yellow-400"></span>}
          </Button>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="h-5 w-5" />
                  {notifications > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] font-medium text-destructive-foreground">
                      {notifications}
                    </span>
                  )}
                  <span className="sr-only">Notifications</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>You have {notifications} new notifications</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user?.avatar || ""} alt={user?.name || "User"} />
                  <AvatarFallback>
                    {user?.name
                      ?.split(" ")
                      .map((n: string) => n[0])
                      .join("") || "U"}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <User className="mr-2 h-4 w-4" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar (Desktop) */}
        <aside className="hidden w-64 flex-col border-r bg-background lg:flex dark:bg-slate-950 dark:border-slate-800">
          <div className="flex h-14 items-center border-b px-4 dark:border-slate-800">
            <Link href="/dashboard" className="flex items-center gap-2">
              <Globe className="h-6 w-6 text-primary" />
              <span className="text-lg font-bold">TambuaFlow</span>
            </Link>
          </div>
          <nav className="flex-1 overflow-auto p-4">
            <div className="grid gap-1 mb-8">
              <SidebarItem icon={Home} title="Home" href="/dashboard" isActive={pathname === "/dashboard"} />
              <SidebarItem
                icon={LineChart}
                title="Competitive Analysis"
                isActive={pathname.includes("/dashboard/competitive-analysis")}
                subItems={competitiveAnalysisSubItems}
              />
              <SidebarItem
                icon={Globe}
                title="Social Impact"
                isActive={pathname.includes("/dashboard/social-impact")}
                subItems={socialImpactSubItems}
              />
              <SidebarItem
                icon={Heart}
                title="Community Engagement"
                isActive={pathname.includes("/dashboard/community")}
                subItems={communityEngagementSubItems}
              />
              <SidebarItem
                icon={PieChart}
                title="Predictive Analytics"
                isActive={pathname.includes("/dashboard/predictive")}
                subItems={predictiveAnalyticsSubItems}
              />
              <SidebarItem
                icon={Search}
                title="Social Listening"
                isActive={pathname.includes("/dashboard/social-listening")}
                subItems={socialListeningSubItems}
                badge="New"
              />
              <SidebarItem
                icon={Users}
                title="Lead Generation"
                isActive={pathname.includes("/dashboard/lead-generation")}
                subItems={leadGenerationSubItems}
              />
              <SidebarItem
                icon={AlertTriangle}
                title="Crisis Management"
                isActive={pathname.includes("/dashboard/crisis-management")}
                subItems={crisisManagementSubItems}
                badge="Alert"
                badgeVariant="destructive"
              />
              <SidebarItem
                icon={Calendar}
                title="Content Calendar"
                isActive={pathname.includes("/dashboard/content-calendar")}
                subItems={contentCalendarSubItems}
              />
              <SidebarItem
                icon={Zap}
                title="Command Center"
                isActive={pathname.includes("/dashboard/command-center")}
                subItems={commandCenterSubItems}
              />
            </div>
            <div className="mt-6 space-y-1">
              <SidebarItem
                icon={Settings}
                title="Settings"
                href="/dashboard/settings"
                isActive={pathname === "/dashboard/settings"}
              />
              <SidebarItem icon={LogOut} title="Logout" onClick={handleLogout} />
            </div>
          </nav>
          <div className="border-t p-4 dark:border-slate-800">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarImage src={user?.avatar || ""} alt={user?.name || "User"} />
                <AvatarFallback>
                  {user?.name
                    ?.split(" ")
                    .map((n: string) => n[0])
                    .join("") || "U"}
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <span className="text-sm font-medium">{user?.name || "User"}</span>
                <span className="text-xs text-muted-foreground">{user?.email || "user@example.com"}</span>
              </div>
              <Button variant="ghost" size="icon" onClick={toggleTheme} className="ml-auto">
                {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <div className="flex h-14 items-center gap-4 border-b bg-background px-4 lg:h-[60px] lg:px-6 dark:bg-slate-950 dark:border-slate-800">
            <div className="hidden lg:flex lg:flex-1">
              <form className="w-full lg:w-auto">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search..."
                    className="w-full bg-background pl-8 md:w-[300px] lg:w-[300px] dark:bg-slate-950 dark:border-slate-800"
                  />
                </div>
              </form>
            </div>
            <div className="flex items-center gap-2 lg:ml-auto">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="sm" className="h-8 gap-1">
                      <Plus className="h-4 w-4" />
                      <span className="hidden sm:inline-block">Add Competitor</span>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Add a new competitor to track</TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 relative">
                      <Bell className="h-4 w-4" />
                      {notifications > 0 && (
                        <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] font-medium text-destructive-foreground">
                          {notifications}
                        </span>
                      )}
                      <span className="sr-only">Notifications</span>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>You have {notifications} new notifications</TooltipContent>
                </Tooltip>
              </TooltipProvider>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.avatar || ""} alt={user?.name || "User"} />
                      <AvatarFallback>
                        {user?.name
                          ?.split(" ")
                          .map((n: string) => n[0])
                          .join("") || "U"}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
          <div className="p-4 md:p-6">{children}</div>
        </main>
      </div>
    </div>
  )
}

