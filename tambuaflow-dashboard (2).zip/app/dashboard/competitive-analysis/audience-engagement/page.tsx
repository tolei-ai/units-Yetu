import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Download, Share2, BadgePlus, ArrowUpRight, BarChart, LineChart } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function AudienceEngagementPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Audience & Engagement Trends</h1>
          <p className="text-muted-foreground">How engaged is your audience compared to competitors?</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button className="gap-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-600/90 hover:to-blue-600/90 text-white dark:from-indigo-500 dark:to-blue-500">
            <Share2 className="h-4 w-4" />
            Share
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Engagement Metrics Comparison</CardTitle>
          <CardDescription>Key metrics compared against industry averages and top competitors</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[180px]">Metric</TableHead>
                <TableHead>Your Business</TableHead>
                <TableHead>Industry Avg.</TableHead>
                <TableHead>Top Competitor</TableHead>
                <TableHead className="text-right">Performance</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">Engagement Rate</TableCell>
                <TableCell>
                  <div className="font-semibold flex items-center">
                    6.8% <ArrowUpRight className="text-green-500 ml-1 h-4 w-4" />
                  </div>
                </TableCell>
                <TableCell>3.2%</TableCell>
                <TableCell>8.4% (Company X)</TableCell>
                <TableCell className="text-right">
                  <span className="inline-flex items-center rounded-full bg-green-50 px-2 py-1 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
                    +112.5%
                  </span>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Sentiment Score</TableCell>
                <TableCell>
                  <div className="font-semibold flex items-center">
                    92/100 <ArrowUpRight className="text-green-500 ml-1 h-4 w-4" />
                  </div>
                </TableCell>
                <TableCell>78/100</TableCell>
                <TableCell>94/100 (Company Y)</TableCell>
                <TableCell className="text-right">
                  <span className="inline-flex items-center rounded-full bg-green-50 px-2 py-1 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
                    +17.9%
                  </span>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Follower Growth</TableCell>
                <TableCell>
                  <div className="font-semibold flex items-center">
                    24.3% <ArrowUpRight className="text-green-500 ml-1 h-4 w-4" />
                  </div>
                </TableCell>
                <TableCell>12.6%</TableCell>
                <TableCell>30.5% (Industry Leader)</TableCell>
                <TableCell className="text-right">
                  <span className="inline-flex items-center rounded-full bg-green-50 px-2 py-1 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
                    +92.9%
                  </span>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Retention Rate</TableCell>
                <TableCell>
                  <div className="font-semibold flex items-center">
                    85% <ArrowUpRight className="text-green-500 ml-1 h-4 w-4" />
                  </div>
                </TableCell>
                <TableCell>69%</TableCell>
                <TableCell>88% (Company X)</TableCell>
                <TableCell className="text-right">
                  <span className="inline-flex items-center rounded-full bg-green-50 px-2 py-1 text-xs font-medium text-green-700 dark:bg-green-900/30 dark:text-green-400">
                    +23.2%
                  </span>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>

          <div className="mt-6 p-4 border rounded-lg bg-amber-50 dark:bg-amber-950/30">
            <h4 className="font-medium text-amber-800 dark:text-amber-400 mb-1 flex items-center">
              <BadgePlus className="h-4 w-4 mr-2" />
              Opportunity Analysis
            </h4>
            <p className="text-sm text-amber-700 dark:text-amber-400/90">
              While your engagement metrics outperform industry averages, there's a gap between your metrics and the top
              competitor in your niche. Focus on interactive content to close this gap.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Engagement by Platform</CardTitle>
            <CardDescription>Performance across different social media channels</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium">Instagram</h4>
                  <span className="text-sm font-medium">8.4%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-pink-500 to-rose-500 rounded-full"
                    style={{ width: "84%" }}
                  ></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium">Facebook</h4>
                  <span className="text-sm font-medium">6.2%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full"
                    style={{ width: "62%" }}
                  ></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium">Twitter/X</h4>
                  <span className="text-sm font-medium">7.5%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-sky-400 to-blue-600 rounded-full"
                    style={{ width: "75%" }}
                  ></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium">LinkedIn</h4>
                  <span className="text-sm font-medium">5.1%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-600 to-blue-800 rounded-full"
                    style={{ width: "51%" }}
                  ></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium">TikTok</h4>
                  <span className="text-sm font-medium">9.8%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 to-teal-500 rounded-full"
                    style={{ width: "98%" }}
                  ></div>
                </div>
              </div>
            </div>
            <div className="mt-6 text-sm text-muted-foreground">
              <p className="italic">
                Note: TikTok shows the highest engagement rate, suggesting potential for increased focus.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Content Type Performance</CardTitle>
            <CardDescription>Engagement rates by content format</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[280px] bg-muted/30 rounded-md relative overflow-hidden border mb-4">
              {/* Simulated bar chart of content performance */}
              <div className="absolute inset-0 p-6 flex items-end justify-around">
                <div className="flex flex-col items-center">
                  <div
                    className="w-10 bg-gradient-to-t from-indigo-600 to-blue-400 rounded-t-md"
                    style={{ height: "180px" }}
                  ></div>
                  <div className="mt-2 text-xs">Video</div>
                </div>
                <div className="flex flex-col items-center">
                  <div
                    className="w-10 bg-gradient-to-t from-indigo-600 to-blue-400 rounded-t-md"
                    style={{ height: "135px" }}
                  ></div>
                  <div className="mt-2 text-xs">Images</div>
                </div>
                <div className="flex flex-col items-center">
                  <div
                    className="w-10 bg-gradient-to-t from-indigo-600 to-blue-400 rounded-t-md"
                    style={{ height: "200px" }}
                  ></div>
                  <div className="mt-2 text-xs">Polls</div>
                </div>
                <div className="flex flex-col items-center">
                  <div
                    className="w-10 bg-gradient-to-t from-indigo-600 to-blue-400 rounded-t-md"
                    style={{ height: "90px" }}
                  ></div>
                  <div className="mt-2 text-xs">Text</div>
                </div>
                <div className="flex flex-col items-center">
                  <div
                    className="w-10 bg-gradient-to-t from-indigo-600 to-blue-400 rounded-t-md"
                    style={{ height: "120px" }}
                  ></div>
                  <div className="mt-2 text-xs">Stories</div>
                </div>
                <div className="flex flex-col items-center">
                  <div
                    className="w-10 bg-gradient-to-t from-indigo-600 to-blue-400 rounded-t-md"
                    style={{ height: "160px" }}
                  ></div>
                  <div className="mt-2 text-xs">Lives</div>
                </div>
              </div>

              {/* Y-axis */}
              <div className="absolute top-0 left-0 bottom-0 w-12 flex flex-col justify-between p-6">
                <div className="text-xs text-muted-foreground">10%</div>
                <div className="text-xs text-muted-foreground">5%</div>
                <div className="text-xs text-muted-foreground">0%</div>
              </div>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Content Type</TableHead>
                  <TableHead>Your Engagement</TableHead>
                  <TableHead>Industry Avg.</TableHead>
                  <TableHead>Top Competitor</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Videos 🎥</TableCell>
                  <TableCell className="text-indigo-600 dark:text-indigo-400 font-medium">8.2% 🚀</TableCell>
                  <TableCell>5.4%</TableCell>
                  <TableCell>9.3% (Company A)</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Polls & Q&A 📊</TableCell>
                  <TableCell className="text-indigo-600 dark:text-indigo-400 font-medium">9.1% 🎯</TableCell>
                  <TableCell>6.7%</TableCell>
                  <TableCell>10.5% (Company B)</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Blogs & Articles</TableCell>
                  <TableCell className="text-indigo-600 dark:text-indigo-400 font-medium">4.3% 📈</TableCell>
                  <TableCell>2.8%</TableCell>
                  <TableCell>6.8% (Company C)</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Engagement Insights</CardTitle>
          <CardDescription>Key takeaways from your audience engagement analysis</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start gap-2">
              <div className="mt-0.5 h-5 w-5 flex items-center justify-center rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                ✓
              </div>
              <div>
                <p>You outperform the industry average but need to increase engagement frequency.</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="mt-0.5 h-5 w-5 flex items-center justify-center rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                ✓
              </div>
              <div>
                <p>Top competitors rely on interactive content and video strategy.</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="mt-0.5 h-5 w-5 flex items-center justify-center rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                ✓
              </div>
              <div>
                <p>TikTok and Instagram show the highest engagement rates; consider increasing presence.</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="mt-0.5 h-5 w-5 flex items-center justify-center rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                ✓
              </div>
              <div>
                <p>Interactive content formats (polls, Q&As) consistently outperform static content.</p>
              </div>
            </div>
          </div>

          <div className="mt-6 grid gap-4 grid-cols-1 md:grid-cols-2">
            <div className="p-4 border rounded-lg bg-indigo-50 dark:bg-indigo-950/30">
              <h4 className="font-medium text-indigo-800 dark:text-indigo-400 mb-1 flex items-center">
                <LineChart className="h-4 w-4 mr-2" />
                Short-term Recommendations
              </h4>
              <ul className="text-sm text-indigo-700 dark:text-indigo-400/90 space-y-1 ml-6 list-disc">
                <li>Increase TikTok posting frequency to 4-5 times per week</li>
                <li>Develop more interactive poll-based content</li>
                <li>Create response videos to trending topics</li>
                <li>Implement weekly Q&A sessions across platforms</li>
              </ul>
            </div>
            <div className="p-4 border rounded-lg bg-blue-50 dark:bg-blue-950/30">
              <h4 className="font-medium text-blue-800 dark:text-blue-400 mb-1 flex items-center">
                <BarChart className="h-4 w-4 mr-2" />
                Long-term Strategy
              </h4>
              <ul className="text-sm text-blue-700 dark:text-blue-400/90 space-y-1 ml-6 list-disc">
                <li>Build dedicated video production team</li>
                <li>Develop cross-platform content strategy</li>
                <li>Implement audience segmentation for targeted content</li>
                <li>Create engagement incentive programs for followers</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-4">
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Download Engagement Report
        </Button>
        <Button className="gap-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-600/90 hover:to-blue-600/90 text-white dark:from-indigo-500 dark:to-blue-500">
          <Share2 className="h-4 w-4" />
          Share Report
        </Button>
      </div>
    </div>
  )
}

