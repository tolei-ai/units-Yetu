import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Share2, ArrowUpRight } from "lucide-react"

export default function MarketPositioningPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Market Positioning</h1>
          <p className="text-muted-foreground">Where does your brand stand against competitors?</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button className="gap-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-600/90 hover:to-blue-600/90 text-white dark:from-indigo-500 dark:to-blue-500">
            <Share2 className="h-4 w-4" />
            Share
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Top 3 Competitors in Your Niche</CardTitle>
            <CardDescription>Market Share Percentage</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Competitor A</div>
                  <div>23%</div>
                </div>
                <div className="h-2 w-full rounded-full bg-muted">
                  <div className="h-2 rounded-full bg-destructive" style={{ width: "23%" }}></div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Competitor B</div>
                  <div>21%</div>
                </div>
                <div className="h-2 w-full rounded-full bg-muted">
                  <div className="h-2 rounded-full bg-amber-500" style={{ width: "21%" }}></div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="font-medium">You</div>
                  <div>18%</div>
                </div>
                <div className="h-2 w-full rounded-full bg-muted">
                  <div className="h-2 rounded-full bg-indigo-600 dark:bg-indigo-500" style={{ width: "18%" }}></div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Competitor C</div>
                  <div>15%</div>
                </div>
                <div className="h-2 w-full rounded-full bg-muted">
                  <div className="h-2 rounded-full bg-green-500" style={{ width: "15%" }}></div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="font-medium">Others</div>
                  <div>23%</div>
                </div>
                <div className="h-2 w-full rounded-full bg-muted">
                  <div className="h-2 rounded-full bg-gray-500" style={{ width: "23%" }}></div>
                </div>
              </div>
            </div>
            <div className="pt-6 text-sm text-muted-foreground">
              <p>Last Updated: 2 days ago</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Positioning Map</CardTitle>
            <CardDescription>Visual graph of brand positioning by growth rate & influence</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative h-[300px] bg-muted/50 rounded-md overflow-hidden">
              {/* This would be a real chart in production */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-full h-full p-6">
                  {/* Simulated positioning map */}
                  <div className="relative w-full h-full">
                    {/* Axes */}
                    <div className="absolute left-0 bottom-0 w-full h-0.5 bg-foreground/20"></div>
                    <div className="absolute left-0 bottom-0 h-full w-0.5 bg-foreground/20"></div>

                    {/* Axis labels */}
                    <div className="absolute bottom-2 right-2 text-xs text-muted-foreground">Growth Rate →</div>
                    <div className="absolute -rotate-90 left-2 top-1/2 text-xs text-muted-foreground">← Influence</div>

                    {/* Competitor dots */}
                    <div
                      className="absolute left-[70%] bottom-[60%] w-8 h-8 rounded-full bg-destructive flex items-center justify-center text-xs text-white shadow-lg"
                      title="Competitor A"
                    >
                      A
                    </div>
                    <div
                      className="absolute left-[60%] bottom-[70%] w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center text-xs text-white shadow-lg"
                      title="Competitor B"
                    >
                      B
                    </div>
                    <div
                      className="absolute left-[50%] bottom-[50%] w-10 h-10 rounded-full bg-indigo-600 dark:bg-indigo-500 flex items-center justify-center text-xs text-white shadow-lg border-2 border-white dark:border-slate-900"
                      title="You"
                    >
                      You
                    </div>
                    <div
                      className="absolute left-[30%] bottom-[40%] w-8 h-8 rounded-full bg-muted-foreground flex items-center justify-center text-xs text-white shadow-lg"
                      title="Competitor C"
                    >
                      C
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-4 p-4 bg-amber-50 dark:bg-amber-950/30 rounded-md">
              <h4 className="font-medium mb-1 text-amber-800 dark:text-amber-400">Growth Opportunity</h4>
              <p className="text-sm text-amber-700 dark:text-amber-400/80">
                Your current position shows moderate influence and growth rate. There's opportunity to grow by targeting
                competitor B's market segment.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Insights</CardTitle>
          <CardDescription>Key takeaways from your market positioning analysis</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start gap-2">
              <div className="mt-0.5 h-5 w-5 flex items-center justify-center rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                ✓
              </div>
              <div>
                <p>You hold 18% of the market—opportunities to scale exist.</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="mt-0.5 h-5 w-5 flex items-center justify-center rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                ✓
              </div>
              <div>
                <p>Competitor A leads in market share but has a weaker engagement rate.</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="mt-0.5 h-5 w-5 flex items-center justify-center rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                ✓
              </div>
              <div>
                <p>Targeting competitor B's audience segment could yield growth.</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Market Overview</TabsTrigger>
          <TabsTrigger value="trends">Growth Trends</TabsTrigger>
          <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Market Overview</CardTitle>
              <CardDescription>Current market landscape and positioning</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>
                  Your company currently holds 18% of the market share, positioning you as the third largest player in
                  your industry. The market is currently dominated by Competitor A (23%) and Competitor B (21%), with
                  several smaller players making up the remaining 38%.
                </p>
                <p>
                  Your growth rate of 15% year-over-year exceeds the industry average of 8%, indicating strong momentum
                  and potential for increased market share in the coming quarters.
                </p>
                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="border rounded-lg p-4 text-center">
                    <div className="text-sm text-muted-foreground mb-1">Your Growth Rate</div>
                    <div className="text-2xl font-bold text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                      15% <ArrowUpRight className="h-4 w-4 ml-1" />
                    </div>
                  </div>
                  <div className="border rounded-lg p-4 text-center">
                    <div className="text-sm text-muted-foreground mb-1">Industry Average</div>
                    <div className="text-2xl font-bold">8%</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="trends" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Growth Trends</CardTitle>
              <CardDescription>Historical and projected market share changes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] bg-muted/30 rounded-md flex items-center justify-center mb-4 p-4 relative border">
                {/* Simulated growth trend line chart */}
                <div className="absolute inset-x-10 bottom-10 h-[1px] bg-foreground/20"></div>
                <div className="absolute inset-y-10 left-10 w-[1px] bg-foreground/20"></div>

                {/* Y-axis labels */}
                <div className="absolute left-3 top-10 text-xs text-muted-foreground">25%</div>
                <div className="absolute left-3 top-[50%] text-xs text-muted-foreground">15%</div>
                <div className="absolute left-3 bottom-8 text-xs text-muted-foreground">0%</div>

                {/* X-axis labels */}
                <div className="absolute bottom-2 left-10 text-xs text-muted-foreground">2022</div>
                <div className="absolute bottom-2 left-[50%] text-xs text-muted-foreground">2023</div>
                <div className="absolute bottom-2 right-10 text-xs text-muted-foreground">2024</div>

                {/* Trend lines */}
                <div className="absolute left-10 right-10 bottom-10 top-10">
                  {/* Your company line */}
                  <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                    <path
                      d="M0,80 C20,70 40,60 60,45 C80,30 100,25 100,25"
                      fill="none"
                      stroke="hsl(226, 70%, 55%)"
                      strokeWidth="2"
                    />
                    <circle cx="100" cy="25" r="3" fill="hsl(226, 70%, 55%)" />
                  </svg>

                  {/* Competitor A line */}
                  <svg className="w-full h-full absolute inset-0" viewBox="0 0 100 100" preserveAspectRatio="none">
                    <path
                      d="M0,30 C30,35 60,30 100,20"
                      fill="none"
                      stroke="hsl(0, 91%, 65%)"
                      strokeWidth="2"
                      strokeDasharray="3,2"
                    />
                  </svg>

                  {/* Competitor B line */}
                  <svg className="w-full h-full absolute inset-0" viewBox="0 0 100 100" preserveAspectRatio="none">
                    <path
                      d="M0,40 C30,35 70,35 100,30"
                      fill="none"
                      stroke="hsl(45, 93%, 47%)"
                      strokeWidth="2"
                      strokeDasharray="3,2"
                    />
                  </svg>
                </div>

                {/* Legend */}
                <div className="absolute top-2 right-2 flex flex-col gap-1 bg-background/80 p-1 rounded text-xs">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-1 bg-indigo-600 dark:bg-indigo-500"></div>
                    <span>Your Company</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-1 bg-destructive"></div>
                    <span>Competitor A</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-1 bg-amber-500"></div>
                    <span>Competitor B</span>
                  </div>
                </div>
              </div>
              <div className="space-y-4">
                <p>
                  Your market share has grown from 12% to 18% over the past 24 months, representing a 50% increase. At
                  the current trajectory, you are projected to reach 22% market share within the next 12 months,
                  potentially overtaking Competitor B.
                </p>
                <p>
                  This growth outpaces all major competitors, with Competitor A showing signs of market share decline
                  (-3% year-over-year).
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="opportunities" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Growth Opportunities</CardTitle>
              <CardDescription>Strategic areas for market expansion</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="mt-0.5 h-6 w-6 flex items-center justify-center rounded-full bg-indigo-600 text-white dark:bg-indigo-500">
                    1
                  </div>
                  <div>
                    <p className="font-medium">Target Competitor B's customer base</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Their customers report 15% lower satisfaction scores, creating an opportunity for conversion.
                    </p>
                    <div className="mt-3 p-3 bg-indigo-50 rounded-md dark:bg-indigo-950/30">
                      <p className="text-sm text-indigo-800 dark:text-indigo-300">
                        <strong>Action Item:</strong> Develop targeted marketing campaigns highlighting your superior
                        customer service and responsiveness compared to Competitor B.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="mt-0.5 h-6 w-6 flex items-center justify-center rounded-full bg-indigo-600 text-white dark:bg-indigo-500">
                    2
                  </div>
                  <div>
                    <p className="font-medium">Expand into emerging market segments</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      The sustainability-focused segment is growing 3x faster than the overall market.
                    </p>
                    <div className="mt-3 p-3 bg-indigo-50 rounded-md dark:bg-indigo-950/30">
                      <p className="text-sm text-indigo-800 dark:text-indigo-300">
                        <strong>Action Item:</strong> Develop and promote eco-friendly product lines and messaging to
                        capture the rapidly growing sustainability-conscious market segment.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="mt-0.5 h-6 w-6 flex items-center justify-center rounded-full bg-indigo-600 text-white dark:bg-indigo-500">
                    3
                  </div>
                  <div>
                    <p className="font-medium">Leverage technological advantage</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Your platform scores 25% higher on innovation metrics compared to competitors.
                    </p>
                    <div className="mt-3 p-3 bg-indigo-50 rounded-md dark:bg-indigo-950/30">
                      <p className="text-sm text-indigo-800 dark:text-indigo-300">
                        <strong>Action Item:</strong> Emphasize your technological innovations in your marketing
                        materials and sales presentations to differentiate from less innovative competitors.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end gap-4">
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Download Market Positioning Report
        </Button>
        <Button className="gap-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-600/90 hover:to-blue-600/90 text-white dark:from-indigo-500 dark:to-blue-500">
          <Share2 className="h-4 w-4" />
          Share Report
        </Button>
      </div>
    </div>
  )
}

