"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Download, Share2, ExternalLink, Plus, Trash2, Edit, Check } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"

// Sample competitor data
const competitors = [
  {
    id: "comp-1",
    name: "Competitor A",
    website: "https://competitora.com",
    facebook: "facebook.com/competitora",
    instagram: "instagram.com/competitora",
    twitter: "twitter.com/competitora",
    linkedin: "linkedin.com/company/competitora",
    tiktok: "tiktok.com/@competitora",
    youtube: "youtube.com/c/competitora",
    marketShare: 23,
    strength: "Product Innovation",
    weakness: "Customer Service",
    notes: "Recently launched a new product line targeting young professionals.",
  },
  {
    id: "comp-2",
    name: "Competitor B",
    website: "https://competitorb.com",
    facebook: "facebook.com/competitorb",
    instagram: "instagram.com/competitorb",
    twitter: "twitter.com/competitorb",
    linkedin: "linkedin.com/company/competitorb",
    tiktok: "tiktok.com/@competitorb",
    youtube: "youtube.com/c/competitorb",
    marketShare: 21,
    strength: "Brand Recognition",
    weakness: "Slow Innovation Cycle",
    notes: "Strong presence in traditional markets, struggling with digital transformation.",
  },
  {
    id: "comp-3",
    name: "Competitor C",
    website: "https://competitorc.com",
    facebook: "facebook.com/competitorc",
    instagram: "instagram.com/competitorc",
    twitter: "twitter.com/competitorc",
    linkedin: "linkedin.com/company/competitorc",
    tiktok: "tiktok.com/@competitorc",
    youtube: "youtube.com/c/competitorc",
    marketShare: 15,
    strength: "Price Point",
    weakness: "Quality Perception",
    notes: "Aggressive pricing strategy, but facing quality concerns from customers.",
  },
  {
    id: "comp-4",
    name: "Industry Newcomer",
    website: "https://newcomer.com",
    facebook: "facebook.com/newcomer",
    instagram: "instagram.com/newcomer",
    twitter: "twitter.com/newcomer",
    linkedin: "linkedin.com/company/newcomer",
    tiktok: "tiktok.com/@newcomer",
    youtube: "youtube.com/c/newcomer",
    marketShare: 5,
    strength: "Digital-First Approach",
    weakness: "Limited Market Reach",
    notes: "Rapidly growing startup with innovative business model.",
  },
]

export default function CompetitorProfilesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [newCompetitor, setNewCompetitor] = useState({
    name: "",
    website: "",
    facebook: "",
    instagram: "",
    twitter: "",
    linkedin: "",
    tiktok: "",
    youtube: "",
    marketShare: "",
    strength: "",
    weakness: "",
    notes: "",
  })

  const filteredCompetitors = competitors.filter((comp) => comp.name.toLowerCase().includes(searchTerm.toLowerCase()))

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewCompetitor((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, you would add the competitor to the database
    console.log("New competitor:", newCompetitor)
    setNewCompetitor({
      name: "",
      website: "",
      facebook: "",
      instagram: "",
      twitter: "",
      linkedin: "",
      tiktok: "",
      youtube: "",
      marketShare: "",
      strength: "",
      weakness: "",
      notes: "",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Competitor Profile Tracker</h1>
          <p className="text-muted-foreground">Monitor key competitor details in real-time</p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button
                variant="default"
                className="gap-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-600/90 hover:to-blue-600/90 text-white dark:from-indigo-500 dark:to-blue-500"
              >
                <Plus className="h-4 w-4" />
                Add Competitor
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Add New Competitor</DialogTitle>
                <DialogDescription>Enter the details of the competitor you want to track</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Company Name</Label>
                      <Input
                        id="name"
                        name="name"
                        value={newCompetitor.name}
                        onChange={handleInputChange}
                        placeholder="Competitor Name"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="website">Website</Label>
                      <Input
                        id="website"
                        name="website"
                        value={newCompetitor.website}
                        onChange={handleInputChange}
                        placeholder="https://example.com"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="facebook">Facebook</Label>
                      <Input
                        id="facebook"
                        name="facebook"
                        value={newCompetitor.facebook}
                        onChange={handleInputChange}
                        placeholder="facebook.com/competitor"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="instagram">Instagram</Label>
                      <Input
                        id="instagram"
                        name="instagram"
                        value={newCompetitor.instagram}
                        onChange={handleInputChange}
                        placeholder="instagram.com/competitor"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="twitter">Twitter/X</Label>
                      <Input
                        id="twitter"
                        name="twitter"
                        value={newCompetitor.twitter}
                        onChange={handleInputChange}
                        placeholder="twitter.com/competitor"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="linkedin">LinkedIn</Label>
                      <Input
                        id="linkedin"
                        name="linkedin"
                        value={newCompetitor.linkedin}
                        onChange={handleInputChange}
                        placeholder="linkedin.com/company/competitor"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="tiktok">TikTok</Label>
                      <Input
                        id="tiktok"
                        name="tiktok"
                        value={newCompetitor.tiktok}
                        onChange={handleInputChange}
                        placeholder="tiktok.com/@competitor"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="youtube">YouTube</Label>
                      <Input
                        id="youtube"
                        name="youtube"
                        value={newCompetitor.youtube}
                        onChange={handleInputChange}
                        placeholder="youtube.com/c/competitor"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="marketShare">Market Share %</Label>
                      <Input
                        id="marketShare"
                        name="marketShare"
                        type="number"
                        min="0"
                        max="100"
                        value={newCompetitor.marketShare}
                        onChange={handleInputChange}
                        placeholder="0-100"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="strength">Key Strength</Label>
                      <Input
                        id="strength"
                        name="strength"
                        value={newCompetitor.strength}
                        onChange={handleInputChange}
                        placeholder="e.g. Customer Service"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="weakness">Key Weakness</Label>
                      <Input
                        id="weakness"
                        name="weakness"
                        value={newCompetitor.weakness}
                        onChange={handleInputChange}
                        placeholder="e.g. Pricing"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes</Label>
                    <Input
                      id="notes"
                      name="notes"
                      value={newCompetitor.notes}
                      onChange={handleInputChange}
                      placeholder="Additional information about this competitor"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <DialogClose asChild>
                    <Button type="button" variant="outline">
                      Cancel
                    </Button>
                  </DialogClose>
                  <DialogClose asChild>
                    <Button
                      type="submit"
                      className="bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-600/90 hover:to-blue-600/90 text-white dark:from-indigo-500 dark:to-blue-500"
                    >
                      <Check className="h-4 w-4 mr-2" />
                      Add Competitor
                    </Button>
                  </DialogClose>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button variant="outline" className="gap-2">
            <Share2 className="h-4 w-4" />
            Share
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle>Competitor List</CardTitle>
          <div className="relative max-w-sm">
            <Input
              type="search"
              placeholder="Search competitors..."
              className="max-w-sm pl-8"
              value={searchTerm}
              onChange={handleSearchChange}
            />
            <div className="absolute inset-y-0 left-0 flex items-center pl-2 text-muted-foreground">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[200px]">Competitor</TableHead>
                  <TableHead>Website</TableHead>
                  <TableHead>Social Media</TableHead>
                  <TableHead>Market Share</TableHead>
                  <TableHead>Key Insight</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCompetitors.map((competitor) => (
                  <TableRow key={competitor.id}>
                    <TableCell className="font-medium">{competitor.name}</TableCell>
                    <TableCell>
                      <a
                        href={competitor.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center text-blue-600 hover:underline dark:text-blue-400"
                      >
                        {competitor.website.replace("https://", "")}
                        <ExternalLink className="h-3 w-3 ml-1" />
                      </a>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-1">
                        <Badge
                          variant="outline"
                          className="bg-blue-50 text-blue-700 hover:bg-blue-100 dark:bg-blue-950 dark:text-blue-300"
                        >
                          <a href={`https://${competitor.facebook}`} target="_blank" rel="noopener noreferrer">
                            FB
                          </a>
                        </Badge>
                        <Badge
                          variant="outline"
                          className="bg-pink-50 text-pink-700 hover:bg-pink-100 dark:bg-pink-950 dark:text-pink-300"
                        >
                          <a href={`https://${competitor.instagram}`} target="_blank" rel="noopener noreferrer">
                            IG
                          </a>
                        </Badge>
                        <Badge
                          variant="outline"
                          className="bg-sky-50 text-sky-700 hover:bg-sky-100 dark:bg-sky-950 dark:text-sky-300"
                        >
                          <a href={`https://${competitor.twitter}`} target="_blank" rel="noopener noreferrer">
                            X
                          </a>
                        </Badge>
                        <Badge
                          variant="outline"
                          className="bg-indigo-50 text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950 dark:text-indigo-300"
                        >
                          <a href={`https://${competitor.linkedin}`} target="_blank" rel="noopener noreferrer">
                            LI
                          </a>
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={competitor.marketShare > 20 ? "default" : "secondary"}
                        className={
                          competitor.marketShare > 20
                            ? "bg-amber-500 hover:bg-amber-600"
                            : competitor.marketShare > 10
                              ? "bg-blue-500 hover:bg-blue-600"
                              : ""
                        }
                      >
                        {competitor.marketShare}%
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className="inline-block max-w-xs truncate" title={competitor.notes}>
                        {competitor.notes}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Competitor Strengths & Weaknesses</CardTitle>
            <CardDescription>Analyze key advantages and disadvantages</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Competitor</TableHead>
                  <TableHead>Key Strength</TableHead>
                  <TableHead>Key Weakness</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {competitors.map((competitor) => (
                  <TableRow key={`sw-${competitor.id}`}>
                    <TableCell className="font-medium">{competitor.name}</TableCell>
                    <TableCell className="text-green-600 dark:text-green-500">{competitor.strength}</TableCell>
                    <TableCell className="text-red-600 dark:text-red-500">{competitor.weakness}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Competitor Analysis Guidelines</CardTitle>
            <CardDescription>Best practices for monitoring your competition</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-medium dark:bg-indigo-900 dark:text-indigo-300">
                  1
                </div>
                <div>
                  <h3 className="font-medium">Regular Monitoring</h3>
                  <p className="text-sm text-muted-foreground">
                    Set a routine schedule to check competitor profiles and look for changes.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-medium dark:bg-indigo-900 dark:text-indigo-300">
                  2
                </div>
                <div>
                  <h3 className="font-medium">Social Media Analysis</h3>
                  <p className="text-sm text-muted-foreground">
                    Track posting frequency, content type, and engagement metrics across platforms.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-medium dark:bg-indigo-900 dark:text-indigo-300">
                  3
                </div>
                <div>
                  <h3 className="font-medium">Website Updates</h3>
                  <p className="text-sm text-muted-foreground">
                    Monitor for new offerings, positioning changes, or messaging updates.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-medium dark:bg-indigo-900 dark:text-indigo-300">
                  4
                </div>
                <div>
                  <h3 className="font-medium">Campaign Tracking</h3>
                  <p className="text-sm text-muted-foreground">
                    Document and analyze competitor marketing campaigns and their effectiveness.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end gap-4">
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Download Competitor Profiles
        </Button>
        <Button className="gap-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-600/90 hover:to-blue-600/90 text-white dark:from-indigo-500 dark:to-blue-500">
          <Share2 className="h-4 w-4" />
          Share Profiles
        </Button>
      </div>
    </div>
  )
}

