import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Facebook, Instagram, Search, Twitter, Plus, RefreshCw, ExternalLink } from "lucide-react"
\
export default function BrandMentionsPage()
Plus, RefreshCw, ExternalLink
} from "lucide-react"

export default function BrandMentionsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Brand Mentions</h1>
        <p className="text-muted-foreground">Track real-time discussions about your organization</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="relative w-full sm:w-auto max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input type="search" placeholder="Search mentions..." className="pl-8 w-full" />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Plus className="mr-2 h-4 w-4" />
            Add Keyword
          </Button>
          <Button variant="outline" size="sm">
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh Data
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Mentions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,342</div>
            <p className="text-xs text-muted-foreground">+18.2% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Sentiment Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8.7/10</div>
            <p className="text-xs text-muted-foreground">+3.2% improvement</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Trending Topics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5 New</div>
            <p className="text-xs text-muted-foreground">+3 from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Response Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">92%</div>
            <p className="text-xs text-muted-foreground">+5% increase</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Platforms</TabsTrigger>
          <TabsTrigger value="twitter">Twitter</TabsTrigger>
          <TabsTrigger value="facebook">Facebook</TabsTrigger>
          <TabsTrigger value="instagram">Instagram</TabsTrigger>
          <TabsTrigger value="linkedin">LinkedIn</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Brand Mentions</CardTitle>
              <CardDescription>Latest social media conversations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <Avatar>
                    <AvatarImage src="/placeholder-user.jpg" alt="Jane Cooper" />
                    <AvatarFallback>JC</AvatarFallback>
                  </Avatar>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="font-semibold">Jane Cooper</div>
                      <div className="text-sm text-muted-foreground">@janecooper</div>
                      <Badge variant="outline" className="ml-auto flex items-center gap-1">
                        <Twitter className="h-3 w-3" />
                        <span>Twitter</span>
                      </Badge>
                    </div>
                    <p className="text-sm">
                      Just visited the new @CompanyName development and was blown away by the sustainable features!
                    </p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div>👍 12</div>
                      <div>🔁 8</div>
                      <div>💬 4</div>
                      <div className="ml-auto">2 hours ago</div>
                    </div>
                    <Button variant="outline" size="sm">
                      Reply
                    </Button>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Avatar>
                    <AvatarImage src="/placeholder-user.jpg" alt="Alex Morgan" />
                    <AvatarFallback>AM</AvatarFallback>
                  </Avatar>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="font-semibold">Alex Morgan</div>
                      <div className="text-sm text-muted-foreground">@alexmorgan</div>
                      <Badge variant="outline" className="ml-auto flex items-center gap-1">
                        <Facebook className="h-3 w-3" />
                        <span>Facebook</span>
                      </Badge>
                    </div>
                    <p className="text-sm">
                      The community spaces in the new @CompanyName project are exactly what our neighborhood needed.
                    </p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div>👍 24</div>
                      <div>🔁 15</div>
                      <div>💬 6</div>
                      <div className="ml-auto">5 hours ago</div>
                    </div>
                    <Button variant="outline" size="sm">
                      Reply
                    </Button>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Avatar>
                    <AvatarImage src="/placeholder-user.jpg" alt="Robert Chen" />
                    <AvatarFallback>RC</AvatarFallback>
                  </Avatar>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="font-semibold">Robert Chen</div>
                      <div className="text-sm text-muted-foreground">@robertchen</div>
                      <Badge variant="outline" className="ml-auto flex items-center gap-1">
                        <Instagram className="h-3 w-3" />
                        <span>Instagram</span>
                      </Badge>
                    </div>
                    <p className="text-sm">
                      Looking forward to the open house at @CompanyName's new development this weekend!
                    </p>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div>👍 9</div>
                      <div>🔁 3</div>
                      <div>💬 5</div>
                      <div className="ml-auto">1 day ago</div>
                    </div>
                    <Button variant="outline" size="sm">
                      Reply
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="twitter" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Twitter Mentions</CardTitle>
              <CardDescription>Latest Twitter conversations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-40">
                <p className="text-muted-foreground">Loading Twitter mentions...</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="facebook" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Facebook Mentions</CardTitle>
              <CardDescription>Latest Facebook conversations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-40">
                <p className="text-muted-foreground">Loading Facebook mentions...</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="instagram" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Instagram Mentions</CardTitle>
              <CardDescription>Latest Instagram conversations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-40">
                <p className="text-muted-foreground">Loading Instagram mentions...</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="linkedin" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>LinkedIn Mentions</CardTitle>
              <CardDescription>Latest LinkedIn conversations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-40">
                <p className="text-muted-foreground">Loading LinkedIn mentions...</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end gap-4">
        <Button variant="outline">View All Mentions</Button>
        <Button variant="outline">Export Report</Button>
        <Button>Search Mentions</Button>
      </div>
    </div>
  )
}

