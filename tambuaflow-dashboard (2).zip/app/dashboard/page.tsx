import Link from "next/link"
import {
  BarChart3,
  LineChart,
  PieChart,
  Search,
  Users,
  Heart,
  ArrowUpRight,
  Download,
  Share2,
  ExternalLink,
} from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4 md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome to TambuaFlow</h1>
          <p className="text-muted-foreground">Your complete competitive intelligence platform</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="hidden sm:flex gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button size="sm" className="gap-2">
            <Share2 className="h-4 w-4" />
            Share
          </Button>
        </div>
      </div>

      {/* Key Metrics Overview Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-l-4 border-l-indigo-600 dark:border-l-indigo-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Competitors Tracked</CardTitle>
            <LineChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <div className="flex items-center text-xs text-green-500">
              <ArrowUpRight className="mr-1 h-3 w-3" />
              <span>+2 from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Engagement Rate</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">6.8%</div>
            <div className="flex items-center text-xs text-green-500">
              <ArrowUpRight className="mr-1 h-3 w-3" />
              <span>+0.6% from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Market Share</CardTitle>
            <PieChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">18%</div>
            <div className="flex items-center text-xs text-green-500">
              <ArrowUpRight className="mr-1 h-3 w-3" />
              <span>+2% from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sentiment Score</CardTitle>
            <Search className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">92/100</div>
            <div className="flex items-center text-xs text-green-500">
              <ArrowUpRight className="mr-1 h-3 w-3" />
              <span>+4 from last month</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Access Section */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="col-span-3 md:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">Competitive Intelligence Dashboard</CardTitle>
            <CardDescription>One platform. Total market awareness. Stay ahead, stay competitive.</CardDescription>
          </CardHeader>
          <CardContent className="text-sm">
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-500 mt-0.5">
                  ✓
                </div>
                <span>Track competitors & market positioning</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-500 mt-0.5">
                  ✓
                </div>
                <span>Analyze audience behavior & engagement trends</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-500 mt-0.5">
                  ✓
                </div>
                <span>Monitor content strategies & keyword dominance</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-500 mt-0.5">
                  ✓
                </div>
                <span>Leverage AI-driven insights for growth</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Link href="/dashboard/competitive-analysis/market-positioning" className="w-full">
              <Button className="w-full bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-600/90 hover:to-blue-600/90 text-white dark:from-indigo-500 dark:to-blue-500">
                Explore Competitive Analysis
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card className="col-span-3 md:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-2">
              <Link href="/dashboard/competitive-analysis/market-positioning">
                <Button variant="outline" className="w-full justify-start">
                  <LineChart className="mr-2 h-4 w-4" />
                  <span className="truncate">Market Positioning</span>
                </Button>
              </Link>
              <Link href="/dashboard/competitive-analysis/competitor-profiles">
                <Button variant="outline" className="w-full justify-start">
                  <Users className="mr-2 h-4 w-4" />
                  <span className="truncate">Competitor Profiles</span>
                </Button>
              </Link>
              <Link href="/dashboard/competitive-analysis/ad-spend">
                <Button variant="outline" className="w-full justify-start">
                  <BarChart3 className="mr-2 h-4 w-4" />
                  <span className="truncate">Ad Spend Analysis</span>
                </Button>
              </Link>
              <Link href="/dashboard/competitive-analysis/sentiment">
                <Button variant="outline" className="w-full justify-start">
                  <Heart className="mr-2 h-4 w-4" />
                  <span className="truncate">Sentiment Analysis</span>
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Dashboard Content */}
      <Card>
        <CardHeader>
          <CardTitle>Your Competitive Landscape</CardTitle>
          <CardDescription>Overview of your position in the market</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-8">
            <div>
              <h3 className="text-lg font-medium mb-4">Market Share Distribution</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="font-medium">Your Company</div>
                  <div className="ml-auto">18%</div>
                </div>
                <Progress value={18} className="h-2" />

                <div className="flex items-center">
                  <div className="font-medium">Competitor A</div>
                  <div className="ml-auto">23%</div>
                </div>
                <Progress value={23} className="h-2" />

                <div className="flex items-center">
                  <div className="font-medium">Competitor B</div>
                  <div className="ml-auto">21%</div>
                </div>
                <Progress value={21} className="h-2" />

                <div className="flex items-center">
                  <div className="font-medium">Competitor C</div>
                  <div className="ml-auto">15%</div>
                </div>
                <Progress value={15} className="h-2" />

                <div className="flex items-center">
                  <div className="font-medium">Others</div>
                  <div className="ml-auto">23%</div>
                </div>
                <Progress value={23} className="h-2" />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Engagement Performance</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>Your Engagement Rate</div>
                    <div className="font-medium">6.8%</div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>Industry Average</div>
                    <div className="font-medium">3.2%</div>
                  </div>
                  <div className="flex items-center justify-between text-green-500">
                    <div>Performance vs Industry</div>
                    <div className="font-medium">+112.5%</div>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-4">Sentiment Overview</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-green-500"></span>
                    <span className="flex-1">Positive</span>
                    <span className="font-medium">67%</span>
                  </div>
                  <Progress value={67} className="h-2 bg-muted" />

                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-gray-400"></span>
                    <span className="flex-1">Neutral</span>
                    <span className="font-medium">22%</span>
                  </div>
                  <Progress value={22} className="h-2 bg-muted" />

                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-500"></span>
                    <span className="flex-1">Negative</span>
                    <span className="font-medium">11%</span>
                  </div>
                  <Progress value={11} className="h-2 bg-muted" />
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-end">
              <Button variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Export Data
              </Button>
              <Button className="gap-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-600/90 hover:to-blue-600/90 dark:from-indigo-500 dark:to-blue-500">
                <ExternalLink className="h-4 w-4" />
                View Detailed Analysis
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

