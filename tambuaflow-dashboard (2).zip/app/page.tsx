import Link from "next/link"
import {
  ArrowRight,
  BarChart3,
  Globe,
  Heart,
  LineChart,
  MessageSquare,
  PieChart,
  Search,
  Shield,
  Users,
} from "lucide-react"

import { Button } from "@/components/ui/button"

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-primary/5 to-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">TambuaFlow</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#features" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Features
            </Link>
            <Link href="#testimonials" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Testimonials
            </Link>
            <Link href="#pricing" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Pricing
            </Link>
            <Link href="/signin" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Sign In
            </Link>
            <Link href="/signup">
              <Button>Get Started</Button>
            </Link>
          </nav>
          <div className="flex md:hidden">
            <Link href="/signup">
              <Button>Get Started</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container py-12 md:py-24 lg:py-32 space-y-8">
        <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
            Competitive Intelligence Dashboard
          </h1>
          <p className="max-w-[42rem] leading-normal text-muted-foreground sm:text-xl sm:leading-8">
            Gain actionable insights into your competitors, market positioning, and social impact with our comprehensive analytics platform.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/signup">
              <Button size="lg" className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90">
                Get Started <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button size="lg" variant="outline">
                View Demo
              </Button>
            </Link>
          </div>
        </div>
        
        {/* Dashboard Preview */}
        <div className="mx-auto max-w-5xl">
          <div className="rounded-xl border bg-card p-2 shadow-lg">
            <div className="overflow-hidden rounded-lg border">
              <div className="bg-primary/10 p-4 flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-red-500"></div>
                <div className="h-3 w-3 rounded-full bg-yellow-500"></div>
                <div className="h-3 w-3 rounded-full bg-green-500"></div>
                <div className="ml-2 text-sm font-medium">TambuaFlow Dashboard</div>
              </div>
              <div className="bg-muted/50 aspect-video relative overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-muted-foreground mb-4">Interactive Dashboard Preview</p>
                    <Link href="/dashboard">
                      <Button>View Demo Dashboard</Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="container py-12 md:py-24 lg:py-32 bg-muted/30 rounded-3xl">
        <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Comprehensive Features
          </h2>
          <p className="max-w-[42rem] leading-normal text-muted-foreground sm:text-xl sm:leading-8">
            Everything you need to monitor, analyze, and outperform your competition.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          <div className="flex flex-col items-center text-center p-6 bg-background rounded-xl shadow-md border border-primary/10 hover:border-primary/30 transition-all hover:shadow-lg">
            <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <LineChart className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-2">Competitive Analysis</h3>
            <p className="text-muted-foreground">Track market positioning, audience engagement, and competitor profiles.</p>
          </div>
          <div className="flex flex-col items-center text-center p-6 bg-background rounded-xl shadow-md border border-blue-500/10 hover:border-blue-500/30 transition-all hover:shadow-lg">
            <div className="h-12 w-12 rounded-full bg-blue-500/10 flex items-center justify-center mb-4">
              <Globe className="h-6 w-6 text-blue-500" />
            </div>
            <h3 className="text-xl font-bold mb-2">Social Impact</h3>
            <p className="text-muted-foreground">Measure your organization's impact on business growth, sustainability, and community.</p>
          </div>
          <div className="flex flex-col items-center text-center p-6 bg-background rounded-xl shadow-md border border-pink-500/10 hover:border-pink-500/30 transition-all hover:shadow-lg">
            <div className="h-12 w-12 rounded-full bg-pink-500/10 flex items-center justify-center mb-4">
              <Heart className="h-6 w-6 text-pink-500" />
            </div>
            <h3 className="text-xl font-bold mb-2">Community Engagement</h3>
            <p className="text-muted-foreground">Monitor conversations, sentiment analysis, and feedback across platforms.</p>
          </div>
          <div className="flex flex-col items-center text-center p-6 bg-background rounded-xl shadow-md border border-purple-500/10 hover:border-purple-500/30 transition-all hover:shadow-lg">
            <div className="h-12 w-12 rounded-full bg-purple-500/10 flex items-center justify-center mb-4">
              <PieChart className="h-6 w-6 text-purple-500" />
            </div>
            <h3 className="text-xl font-bold mb-2">Predictive Analytics</h3>
            <p className="text-muted-foreground">Forecast performance, optimal posting times, and content recommendations.</p>
          </div>
          <div className="flex flex-col items-center text-center p-6 bg-background rounded-xl shadow-md border border-amber-500/10 hover:border-amber-500/30 transition-all hover:shadow-lg">
            <div className="h-12 w-12 rounded-full bg-amber-500/10 flex items-center justify-center mb-4">
              <Search className="h-6 w-6 text-amber-500" />
            </div>
            <h3 className="text-xl font-bold mb-2">Social Listening</h3>
            <p className="text-muted-foreground">Track brand mentions, sentiment analysis, and trending topics.</p>
          </div>
          <div className="flex flex-col items-center text-center p-6 bg-background rounded-xl shadow-md border border-green-500/10 hover:border-green-500/30 transition-all hover:shadow-lg">
            <div className="h-12 w-12 rounded-full bg-green-500/10 flex items-center justify-center mb-4">
              <Users className="h-6 w-6 text-green-500" />
            </div>
            <h3 className="text-xl font-bold mb-2">Lead Generation</h3>
            <p className="text-muted-foreground">Manage leads, properties, and campaigns from a central dashboard.</p>
          </div>
          <div className="flex flex-col items-center text-center p-6 bg-background rounded-xl shadow-md border border-red-500/10 hover:border-red-500/30 transition-all hover:shadow-lg">
            <div className="h-12 w-12 rounded-full bg-red-500/10 flex items-center justify-center mb-4">
              <Shield className="h-6 w-6 text-red-500" />
            </div>
            <h3 className="text-xl font-bold mb-2">Crisis Management</h3>
            <p className="text-muted-foreground">Monitor risk, personalized issues, and response planning.</p>
          </div>
          <div className="flex flex-col items-center text-center p-6 bg-background rounded-xl shadow-md border border-indigo-500/10 hover:border-indigo-500/30 transition-all hover:shadow-lg md:col-span-2 lg:col-span-1">
            <div className="h-12 w-12 rounded-full bg-indigo-500/10 flex items-center justify-center mb-4">
              <BarChart3 className="h-6 w-6 text-indigo-500" />
            </div>
            <h3 className="text-xl font-bold mb-2">Command Center</h3>
            <p className="text-muted-foreground">Centralized hub for all your analytics and decision-making needs.</p>
          </div>
          <div className="flex flex-col items-center text-center p-6 bg-background rounded-xl shadow-md border border-orange-500/10 hover:border-orange-500/30 transition-all hover:shadow-lg md:col-span-2 lg:col-span-1">
            <div className="h-12 w-12 rounded-full bg-orange-500/10 flex items-center justify-center mb-4">
              <MessageSquare className="h-6 w-6 text-orange-500" />
            </div>
            <h3 className="text-xl font-bold mb-2">Content Calendar</h3>
            <p className="text-muted-foreground">Plan, schedule, and analyze your content strategy.</p>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="container py-12 md:py-24 lg:py-32">
        <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Trusted by Industry Leaders
          </h2>
          <p className="max-w-[42rem] leading-normal text-muted-foreground sm:text-xl sm:leading-8">
            See what our customers are saying about TambuaFlow.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          <div className="bg-background p-6 rounded-xl shadow-md border border-primary/10 hover:border-primary/30 transition-all hover:shadow-lg">
            <div className="flex items-center mb-4">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <span className="text-primary font-bold">JD</span>
              </div>
              <div>
                <h4 className="font-bold">John Doe</h4>
                <p className="text-sm text-muted-foreground">Marketing Director, ABC Corp</p>
              </div>
            </div>
            <p className="text-muted-foreground">"TambuaFlow has transformed how we approach competitive analysis. The insights we've gained have directly contributed to a 25% increase in market share."</p>
            <div className="flex mt-4">
              <div className="text-amber-500">★★★★★</div>
            </div>
          </div>
          <div className="bg-background p-6 rounded-xl shadow-md border border-primary/10 hover:border-primary/30 transition-all hover:shadow-lg">
            <div className="flex items-center mb-4">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <span className="text-primary font-bold">JS</span>
              </div>
              <div>
                <h4 className="font-bold">Jane Smith</h4>
                <p className="text-sm text-muted-foreground">CEO, XYZ Enterprises</p>
              </div>
            </div>
            <p className="text-muted-foreground">"The social impact metrics have been invaluable for our ESG reporting. We can now quantify our community contributions in ways we never could before."</p>
            <div className="flex mt-4">
              <div className="text-amber-500">★★★★★</div>
            </div>
          </div>
          <div className="bg-background p-6 rounded-xl shadow-md border border-primary/10 hover:border-primary/30 transition-all hover:shadow-lg">
            <div className="flex items-center mb-4">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <span className="text-primary font-bold">RJ</span>
              </div>
              <div>
                <h4 className="font-bold">Robert Johnson</h4>
                <p className="text-sm text-muted-foreground">CMO, Global Solutions</p>
              </div>
            </div>
            <p className="text-muted-foreground">"The crisis management tools helped us navigate a potential PR disaster. We identified the issue early and implemented our response strategy before it escalated."</p>
            <div className="flex mt-4">
              <div className="text-amber-500">★★★★★</div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="container py-12 md:py-24 lg:py-32 bg-muted/30 rounded-3xl">
        <div className="mx-auto flex max-w-[58rem] flex-col items-center justify-center gap-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Simple, Transparent Pricing
          </h2>
          <p className="max-w-[42rem] leading-normal text-muted-foreground sm:text-xl sm:leading-8">
            Choose the plan that's right for your business.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          <div className="bg-background p-6 rounded-xl shadow-md border border-primary/10 hover:border-primary/30 transition-all hover:shadow-lg">
            <div className="text-center mb-6">
              <h3 className="text-xl font-bold">Starter</h3>
              <div className="mt-2">
                <span className="text-3xl font-bold">$99</span>
                <span className="text-muted-foreground">/month</span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">Perfect for small businesses</p>
            </div>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Competitive Analysis</span>
              </li>
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Social Listening</span>
              </li>
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>5 Competitor Profiles</span>
              </li>
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Basic Reporting</span>
              </li>
            </ul>
            <Link href="/signup" className="block">
              <Button className="w-full">Get Started</Button>
            </Link>
          </div>
          <div className="bg-background p-6 rounded-xl shadow-lg border-2 border-primary relative transform scale-105">
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-medium">
              Most Popular
            </div>
            <div className="text-center mb-6">
              <h3 className="text-xl font-bold">Professional</h3>
              <div className="mt-2">
                <span className="text-3xl font-bold">$249</span>
                <span className="text-muted-foreground">/month</span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">Ideal for growing companies</p>
            </div>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Everything in Starter</span>
              </li>
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Community Engagement</span>
              </li>
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Predictive Analytics</span>
              </li>
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>15 Competitor Profiles</span>
              </li>
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Advanced Reporting</span>
              </li>
            </ul>
            <Link href="/signup" className="block">
              <Button className="w-full bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90">Get Started</Button>
            </Link>
          </div>
          <div className="bg-background p-6 rounded-xl shadow-md border border-primary/10 hover:border-primary/30 transition-all hover:shadow-lg">
            <div className="text-center mb-6">
              <h3 className="text-xl font-bold">Enterprise</h3>
              <div className="mt-2">
                <span className="text-3xl font-bold">$499</span>
                <span className="text-muted-foreground">/month</span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">For large organizations</p>
            </div>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Everything in Professional</span>
              </li>
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Social Impact Dashboard</span>
              </li>
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Crisis Management</span>
              </li>
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Unlimited Competitor Profiles</span>
              </li>
              <li className="flex items-center">
                <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  <span className="text-primary text-xs">✓</span>
                </div>
                <span>Custom Integrations</span>
              </li>
            </ul>
            <Link href="/signup" className="block">
              <Button className="w-full">Get Started</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container py-12 md:py-24 lg:py-32">
        <div className="mx-auto max-w-[58rem] rounded-2xl bg-gradient-to-r from-primary to-blue-600 p-8 md:p-12 lg:p-16 text-center text-white">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Ready to Transform Your Competitive Intelligence?
          </h2>
          <p className="mt-4 text-lg md:text-xl opacity-90">
            Join thousands of businesses that use TambuaFlow to gain a competitive edge.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <Link href="/signup">
              <Button size="lg" variant="secondary" className="bg-white text-primary hover:bg-white/90">
                Get Started <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                View Demo
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-muted/40">
        <div className="container py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Globe className="h-6 w-6 text-primary" />
                <span className="text-xl font-bold">TambuaFlow</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Comprehensive competitive intelligence and social impact analytics for forward-thinking organizations.
              </p>
            </div>
            <div>
              <h3 className="font-medium mb-4">Product</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#features" className="text-sm text-muted-foreground hover:text-foreground">
                    Features
                  </Link>
                </li>
                <li>
                  <Link href="#pricing" className="text-sm text-muted-foreground hover:text-foreground">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                    Integrations
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                    Changelog
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-4">Resources</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                    Documentation
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                    Case Studies
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                    Support
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-medium mb-4">Company</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 border-t pt-6 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-muted-foreground">
              © 2025 TambuaFlow. All rights reserved.
            </p>
            <div className="flex items-center gap-4 mt-4 md:mt-0">
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1\

